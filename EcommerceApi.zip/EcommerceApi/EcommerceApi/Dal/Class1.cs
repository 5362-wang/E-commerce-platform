﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dal
{
    public class Class1
    {
        /// <summary>
        /// /抖音记录美好生活
        /// </summary>
        /// <returns></returns>
        public string YangDong()
        {
            //这里是王玺凯添加的
            return "抖音记录美好生活";
        }
    }
}
